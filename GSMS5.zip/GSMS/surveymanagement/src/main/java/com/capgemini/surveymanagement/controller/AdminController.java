package com.capgemini.surveymanagement.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;
import org.apache.log4j.Logger;

import com.capgemini.surveymanagement.bean.AdminBean;
import com.capgemini.surveymanagement.bean.RespondentBean;
import com.capgemini.surveymanagement.bean.SurveyDetails;
import com.capgemini.surveymanagement.bean.SurveyorBean;
import com.capgemini.surveymanagement.exception.AdminNotFoundException;
import com.capgemini.surveymanagement.factory.Factory;
import com.capgemini.surveymanagement.service.Service;

public class AdminController {
	static Service service = Factory.getServiceInstance();
	static AdminBean admin = Factory.getAdminBeanInstance();
	static SurveyDetails survey = Factory.getSurveyDetailsInstance();
	static RespondentBean respondent = Factory.getRespondentBeanInstance();
	static SurveyorBean surveyor = Factory.getSurveyorBeanInstance();
	static final Logger logger = Logger.getLogger(AdminController.class);
	static Scanner sc = new Scanner(System.in);
	static int count = 0;

	private AdminController() {

	}

	 //This method is used for the Admin To Login.
	 
	public static void adminLogin() {
		Properties property = new Properties();
		try {
			property.load(new FileInputStream("db.properties"));
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
		String adminUsername = property.getProperty("adminUsername");
		String adminPassword = property.getProperty("adminPassword");
		logger.info("adminUsername: " + adminUsername);
		logger.info("adminPassword: " + adminPassword);
		try {
			logger.info("Enter Username");
			adminUsername = sc.next();
			while (!service.usernameValidation(adminUsername)) {
				logger.error("Enter valid adminusername");
				adminUsername = sc.next();
			}
			logger.info("Enter Password");
			adminPassword = sc.next();
			while (!service.passwordValidation(adminPassword)) {
				logger.error("Enter valid Credentials");
				adminLogin();
			}
			boolean value = service.adminLoginService(adminUsername, adminPassword);
			if (value) {
				logger.info("Admin Login Successful");
				afterAdminLogin();
			} else {
				throw new AdminNotFoundException();
			}
		} catch (AdminNotFoundException e) {
			logger.error(e.getMessage());
		}
	}

	//After AdminLogin we use this method to perform admin operations.
	 
	public static void afterAdminLogin() {
		I: do {
			logger.info("********************WELCOME ADMIN ************************");
			logger.info("1.Add Surveyor");
			logger.info("2.Add Respondent");
			logger.info("3.Login as Surveyor");
			logger.info("4.Login as Respondent");
			logger.info("5.View all Surveyors");
			logger.info("6.View all Respondents");
			logger.info("7.Exit");
			logger.info("Please Enter your Choice from 1-7");
			String option = sc.next();
			while (!service.adminChoiceValidation(option)) {
				logger.error("Please Enter valid choice between [1-7]");
				option = sc.next();
			}
			int select = Integer.parseInt(option);

			switch (select) {

			case 1:
				logger.info("Add Surveyor");
				addSurveyor();
				break;
			case 2:
				logger.info("Add Respondent");
				addRespondent();
				break;
			case 3:
				logger.info("Surveyor Login");
				SurveyorController.surveyorLogin();
				break;
			case 4:
				logger.info("Respondent Login");
				RespondentController.respondentLogin();
				break;
			case 5:
				logger.info("All Surveyors");
				viewAllSurveyors();
				break;
			case 6:
				logger.info("All Respondents");
				viewAllRespondents();
				break;
			case 7:
				adminLogin();
				System.exit(0);
				sc.close();
				break I;

			default:
				logger.error("Enter a valid choice");
				break;
			}
		} while (true);

	}

	// This method is used to add Surveyor.
	public static void addSurveyor() {
		SurveyorBean surveyor = Factory.getSurveyorBeanInstance();
		logger.info("Enter Surveyor Id :" + ".\n"
				+ "which must be between [0-9] and minimum Digits: 1 and maximum Digits 10");
		String surveyorId = sc.next();
		while (!service.idValidation(surveyorId)) {
			logger.error(
					"Enter a valid surveyorId:" + ".\n" + "which must be between [0-9] and minimum: 1 and maximum: 10");
			surveyorId = sc.next();
		}
		surveyor.setSurveyorId(surveyorId);

		logger.info("Enter Surveyor Username: Accepts only [a-z][A-Z][0-9] space minimum: 2 and maximum: 20");
		String surveyorUsername = sc.next();
		while (!service.usernameValidation(surveyorUsername)) {
			logger.info("Enter a valid username:  Accepts only [a-z][A-Z][0-9] space minimum: 2 and maximum: 20");
			surveyorUsername = sc.next();
		}
		surveyor.setSurveyorUsername(surveyorUsername);

		logger.info("Enter  Surveyor password: Accepts only [a-z][A-Z][0-9] [.%$#@]minimum: 6 and maximum: 20 ");
		String surveyorPassword = sc.next();
		while (!service.passwordValidation(surveyorPassword)) {
			logger.info("Enter a valid password: Accepts only [a-z][A-Z][0-9] [.%$#@]minimum: 6 and maximum: 20");
			surveyorPassword = sc.next();
		}
		surveyor.setSurveyorPassword(surveyorPassword);

		logger.info("Enter mailId: Accepts only [a-z][A-Z][0-9] [.@] minimum:2 and maximum:20 ");
		String mailId = sc.next();
		while (!service.mailIdValidation(mailId)) {
			logger.info("Enter valid mailid: Accepts only [a-z][A-Z][0-9] [.@] minimum:2 and maximum:20 ");
			mailId = sc.next();
		}
		surveyor.setSurveyorMailId(mailId);

		logger.info("Enter Contact Number:  Accepts only [0-9] maximum:10 ");
		String contact = sc.next();
		while (!service.contactValidation(contact)) {
			logger.info("Enter valid contactNumber: Accepts only [0-9] maximum:10");
			contact = sc.next();
		}
		surveyor.setSurveyorContactNumber(contact);

		boolean add = service.addSurveyorService(surveyor);
		if (add) {
			logger.info("SURVEYOR ADDED SUCCESSFULLY");
		} else {
			logger.error("FAILED TO ADD SURVEYOR");
		}
	}

	// This method is used for adding the respondent.
	
	public static void addRespondent() {
		RespondentBean respondent = Factory.getRespondentBeanInstance();
		logger.info("Enter Respondent Username: Accepts only [a-z][A-Z][0-9] space minimum: 2 and maximum: 20");

		String respondentUsername = sc.next();
		while (!service.usernameValidation(respondentUsername)) {
			logger.info(
					"Enter a valid Respondentusername: Accepts only [a-z][A-Z][0-9] space minimum:2 and maximum: 20");
			respondentUsername = sc.next();
		}
		respondent.setRespondentUsername(respondentUsername);

		logger.info("Enter Respondent Password:  Accepts only [a-z][A-Z][0-9] [.%$#@] minimum:4 and maximum: 20");
		String respondentPassword = sc.next();
		while (!service.passwordValidation(respondentPassword)) {
			logger.info("Enter a valid password:  Accepts only [a-z][A-Z][0-9] [.%$#@] min : 4 and max:20 ");
			respondentPassword = sc.next();
		}
		respondent.setRespondentPassword(respondentPassword);

		logger.info("Enter mailId: Accepts only [a-z][A-Z][0-9] [.@] min:2 and max:20 ");
		String mailId = sc.next();
		while (!service.mailIdValidation(mailId)) {
			logger.info("enter valid mailid: Accepts only [a-z][A-Z][0-9] [.@] min:2 and max:20 ");
			mailId = sc.next();
		}
		respondent.setRespondentMailId(mailId);

		logger.info("Enter Contact Number: Accepts only [0-9] max:10");
		String phone = sc.next();
		while (!service.contactValidation(phone)) {
			logger.info("Enter valid contactnumber: Accepts only [0-9] max:10");
			phone = sc.next();
		}
		respondent.setRespondentContactNumber(phone);

		boolean value1 = service.addRespondentService(respondent);
		if (value1) {
			logger.info("Respondent added sucessfully");
		} else {
			logger.info("Respondent Adding Failed");
		}
	}

	//To view all the surveyors we use this method.
	
	public static void viewAllSurveyors() {
		logger.info("Details of all Surveyors !!");
		logger.info(service.viewAllSurveyorsService(surveyor));
	}

	//To view all the respondents we use this method.
	
	public static void viewAllRespondents() {
		logger.info("Details of all Respondents !!");
		logger.info(service.viewAllRespondentService(respondent));
	}
}

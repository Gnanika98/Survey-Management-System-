package com.capgemini.surveymanagement.controller;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.surveymanagement.factory.Factory;
import com.capgemini.surveymanagement.service.Service;

public class MainController {
	static final Logger log = Logger.getLogger(MainController.class);
	static Scanner scanner = new Scanner(System.in);
	static Service service = Factory.getServiceInstance();

	private MainController() {

	}

	public static void main(String[] args) {
		do {
			log.info("----------WELCOME TO SURVEY MANAGEMENT SYSTEM----------");
			log.info("choose your option");
			log.info("1.Admin Login ");
			log.info("2.Surveyor Login");
			log.info("3.Respondent Login");
			log.info("4.Exit");
			String choice1 = scanner.next();
			while (!service.mainChoiceValidation(choice1)) {
				log.info(" Enter valid choice from [1-4]");
				choice1 = scanner.next();
			}
			int choice = Integer.parseInt(choice1);

			switch (choice) {
			case 1:
				AdminController.adminLogin();
				break;
			case 2:
				SurveyorController.surveyorLogin();
				break;
			case 3:
				RespondentController.respondentLogin();
				break;
			case 4:
				System.exit(0);
				scanner.close();
				break;
			default:
				log.info("Enter valid choice");
				break;
			}
		} while (true);

	}
}
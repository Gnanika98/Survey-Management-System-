package com.capgemini.surveymanagement.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.surveymanagement.bean.SurveyDetails;
import com.capgemini.surveymanagement.factory.Factory;

public class SurveyDetailsRepository {

	public static List<SurveyDetails> surveyDetailsRepList = new ArrayList<SurveyDetails>();

	public List<SurveyDetails> defaultSurveyorSurvey() {
		SurveyDetails surveyDetails = Factory.getSurveyDetailsInstance();
		surveyDetails.setSurveyId("1");
		surveyDetails.setSurveyTitle("Javat");
		surveyDetails.setSurveyDescription(
				"Javat is a web developers site,with tutorials and references on web development languages");
		surveyDetails.setQuestion1("How well are you Satisfied with Javat Application");
		surveyDetails.setQ1Option1("Good");
		surveyDetails.setQ1Option2("Excellent");
		surveyDetails.setQ1Option3("Not Bad");
		surveyDetails.setQ1Option4("Bad");
		surveyDetails.setQuestion2("Is the content in the Javat reaching your Expectations");
		surveyDetails.setQ2Option1("yes");
		surveyDetails.setQ2Option2("No");
		surveyDetails.setQ2Option3("can be improved");
		surveyDetails.setQ2Option4("Bad");

		surveyDetails.setQuestion3("Please rate us from [1-5]");
		surveyDetails.setQuestion4("If you faced any problems while using our Application please mention here");
		surveyDetails.setQuestion5("Please Share Your Experience about Javat Application");

		surveyDetailsRepList.add(surveyDetails);

		SurveyDetails surveyDetails1 = Factory.getSurveyDetailsInstance();
		surveyDetails1.setSurveyId("2");
		surveyDetails1.setSurveyTitle("OLX");
		surveyDetails1.setSurveyDescription("OLX marketplace is a platform for buying and selling services and goods "
				+ "such as electronics,fashion items..and many more");
		surveyDetails1.setQuestion1("How much are you satisfied with the OLX Application");
		surveyDetails1.setQ1Option1("Good");
		surveyDetails1.setQ1Option2("Not Bad");
		surveyDetails1.setQ1Option3("Very Good");
		surveyDetails1.setQ1Option4("Bad");
		surveyDetails1.setQuestion2(" How much are our satisfied with the products");
		surveyDetails1.setQ2Option1("Good");
		surveyDetails1.setQ2Option2("Not Bad");
		surveyDetails1.setQ2Option3("Very Good");
		surveyDetails1.setQ2Option4("Bad");
		surveyDetails1.setQuestion3("Please rate us from [1-5]");
		surveyDetails1.setQuestion4("If any complaints regarding our app please mention here.");
		surveyDetails1.setQuestion5("Please share your Experience with our OLX App.");

		surveyDetailsRepList.add(surveyDetails1);
		return surveyDetailsRepList;

	}
}

package com.capgemini.surveymanagement.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.surveymanagement.bean.SurveyorBean;
import com.capgemini.surveymanagement.factory.Factory;

public class SurveyorRepository {
	public static List<SurveyorBean> surveyorRepList = new ArrayList<>();

	public List<SurveyorBean> defaultSurveyorLogin() {
		SurveyorBean surveyor = Factory.getSurveyorBeanInstance();
		surveyor.setSurveyorId("1");
		surveyor.setSurveyorUsername("Surveyor");
		surveyor.setSurveyorPassword("Surveyor@1");
		surveyor.setSurveyorContactNumber("9587125858");
		surveyor.setSurveyorMailId("surveyor1@gmail.com");
		surveyorRepList.add(surveyor);
		return surveyorRepList;
	}
}
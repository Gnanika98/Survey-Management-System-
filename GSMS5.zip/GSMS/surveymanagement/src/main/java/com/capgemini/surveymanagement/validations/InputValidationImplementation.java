package com.capgemini.surveymanagement.validations;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InputValidationImplementation implements InputValidation {
	Pattern pattern = null;
	Matcher matcher = null;
/**
 * This is used to validate the username.
 */
	public boolean usernameValidation(String username) {
		pattern = Pattern.compile("[a-zA-Z0-9]+[\\s[[a-zA-Z0-9]+]{2,20}]");
		matcher = pattern.matcher(username);
		return matcher.matches();

	}
/**
 * This is used to validate password.
 */
	public boolean passwordValidation(String password) {
		pattern = Pattern.compile("(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20}");
		matcher = pattern.matcher(password);
		return matcher.matches();
	}
/**
 * This is used to validate the Id.
 */
	public boolean idValidation(String id) {
		pattern = Pattern.compile("[0-9]{1,100}");
		matcher = pattern.matcher(id);
		return matcher.matches();
	}
/**
 * This is used to validate the answer.
 */
	public boolean answerValidation(String answer) {
		pattern = Pattern.compile("[a-zA-Z]+[\\s[[a-zA-Z][0-9]+]]*"); // [a-zA-Z]+[\\s[[a-zA-Z]+]]*
		matcher = pattern.matcher(answer);
		return matcher.matches();

	}
/**
 * This is used to validate the MailID.
 */
	public boolean mailIdValidation(String mailId) {
		pattern = Pattern.compile(
				"^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z" + "A-Z]{2,20}$");

		matcher = pattern.matcher(mailId);
		return matcher.matches();

	}
/**
 * This is used to validate choice. 
 */
	public boolean choiceValidation(String choice) {
		pattern = Pattern.compile("[0-9]{1,2}");
		matcher = pattern.matcher(choice);
		return matcher.matches();

	}
/**
 * This is used to validate title.
 */
	public boolean titleValidation(String title) {
		pattern = Pattern.compile("[a-zA-Z]+[\\s[[a-zA-Z]+]]*");// "[a-zA-Z0-9]+[\\s[[a-zA-Z0-9@]+]{2,20}]");
		matcher = pattern.matcher(title);
		return matcher.matches();

	}
/**
 * This is used to validate questions.
 */
	public boolean questionValidation(String question) {
		pattern = Pattern.compile("[a-zA-Z.?*]+[\\s[[a-zA-Z][0-9]+]]{1,100}");
		matcher = pattern.matcher(question);
		return matcher.matches();
	}
/**
 * This is used to validate description.
 */
	public boolean descriptionValidation(String description) {

		pattern = Pattern.compile("[a-zA-Z]+[\\s[[a-zA-Z]+]]{1,200}.*");
		matcher = pattern.matcher(description);
		return matcher.matches();

	}
/**
 * This is used to validate contact.
 */
	public boolean contactValidation(String contact) {
		pattern = Pattern.compile("[0-9]{10}");
		matcher = pattern.matcher(contact);
		return matcher.matches();

	}
/**
 * This is used to validate the Choice entered by the admin.
 */
	public boolean adminChoiceValidation(String choice) {
		pattern = Pattern.compile("[1-7]{1}");
		matcher = pattern.matcher(choice);
		return matcher.matches();
	}
/**
 * This is used to validate the choice in the main controller.
 */
	public boolean mainChoiceValidation(String choice) {
		pattern = Pattern.compile("[1-4]{1}");
		matcher = pattern.matcher(choice);
		return matcher.matches();
	}
/**
 * This is used to validate the choice entered by the surveyor.
 */
	public boolean surveyorChoiceValidation(String choice) {
		pattern = Pattern.compile("[1-6]{1}");
		matcher = pattern.matcher(choice);
		return matcher.matches();
	}
/**
 * This is used to validate the choice entered by the respondent. 
 */
	@Override
	public boolean respondentChoiceValidation(String choice) {

		pattern = Pattern.compile("[1-4]{1}");
		matcher = pattern.matcher(choice);
		return matcher.matches();

	}
/**
 * This is used to validate the rate.
 */
	@Override
	public boolean rateValidation(String rate) {
		pattern = Pattern.compile("[1-5]{1}");
		matcher = pattern.matcher(rate);
		return matcher.matches();

	}
}
